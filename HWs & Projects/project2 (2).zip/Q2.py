
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from copy import copy, deepcopy
import random
import math
import pickle
"""create action arrays"""
def define_action_space(i):
  actions=[]
  if(i==1):
    a1=np.array([[0],[0],[0],[0]])
    a2=np.array([[1],[0],[0],[0]])
    a3=np.array([[0],[1],[0],[0]])
    a4=np.array([[0],[0],[1],[0]])
    a5=np.array([[0],[0],[0],[1]])
    actions.append(a1)
    actions.append(a2)
    actions.append(a3)
    actions.append(a4)
    actions.append(a5)
  else:
    a1=np.array([[0],[0],[0],[0]])
    a2=np.array([[1],[0],[0],[0]])
    a3=np.array([[0],[0],[0],[1]])
    actions.append(a1)
    actions.append(a2)
    actions.append(a3)
  return actions

def create_states():
  states=[]
  first_array=np.array([[0],[0],[0],[0]])
  for i in range(16):
    number_list=[]
    byte_string='{0:04b}'.format(i)
    for ch in byte_string:
      number_list.append(int(ch))
    states.append(np.asarray(number_list).reshape(4,1))
  return states
#create_states()
def computeXOR(a,b):
  xor=[]
  for i in range(np.shape(a)[0]):
    if(a[i][0]==b[i][0]):
      ans=0
    else:
      ans=1
    xor.append(ans)
  return np.asarray(xor).reshape(np.shape(a)[0],1)
def computeL1Norm(a):   # assumes input is np array of shape x,1
  norm=0
  for i in range(np.shape(a)[0]):
    norm+=np.abs(a[i][0])
  return norm
def calc_transition_matrices(p,connectivity_matrix,states,actions): # connectivity matrix must be a np array
  rows=len(states)
  transition_matrices=[]
  for action in actions:
    transition_matrix=np.zeros((rows,rows))
    for i in range(rows):
      for j in range(rows):
        csi=np.matmul(connectivity_matrix,states[i])
        csi=np.where(csi > 0, 1, 0)
        xored = computeXOR(csi,action)
        prob=computeL1Norm(states[j]-xored)
        transition_matrix[i][j] = math.pow(p,prob)*math.pow(1-p,4-prob)
    transition_matrices.append(transition_matrix)
  return transition_matrices
def calculate_two_state_reward(state1,state2,action):  # state 2 is the destination state
  return computeL1Norm(5*state2)-computeL1Norm(action)

def create_all_two_state_rewards(states,actions):
  rows=len(states)
  two_state_rewards=[]
  for action in actions:
    two_state_reward=np.zeros((rows,rows))
    for i in range(rows):
      for j in range(rows):
        two_state_reward[i][j]=calculate_two_state_reward(states[i],states[j],action)
    two_state_rewards.append(two_state_reward)
  return two_state_rewards

def create_all_single_state_rewards(two_state_rewards,transition_matrices):
  rows=np.shape(two_state_rewards[0])[0]
  single_state_rewards=[]
  constant=np.ones((rows,1))
  for i in range(len(two_state_rewards)):
    single_state_rewards.append(np.matmul(np.multiply(transition_matrices[i],two_state_rewards[i]),constant))
  return single_state_rewards
def compare_single_state_rewards(p1,p2):
  states=create_states()
  actions=define_action_space(0)
  test_two_state_rewards=create_all_two_state_rewards(states,actions)
  connectivity_matrix = np.array([[0,0,-1,0],[1,0,-1,-1],[0,1,0,0],[-1,1,1,0]])
  test_txn_matrices=calc_transition_matrices(p1,connectivity_matrix,states,actions)
  test_single_state_reward = create_all_single_state_rewards(test_two_state_rewards,test_txn_matrices)
  states2=create_states()
  actions2=define_action_space(0)
  test_two_state_rewards2=create_all_two_state_rewards(states,actions)
  test_txn_matrices2=calc_transition_matrices(p2,connectivity_matrix,states,actions)
  test_single_state_reward2 = create_all_single_state_rewards(test_two_state_rewards2,test_txn_matrices2)
  output = [test_single_state_reward2[i]-test_single_state_reward[i] for i in range(len(test_single_state_reward))]
  print(output[1])
compare_single_state_rewards(0.05,0.45)
def matrix_policy_improv(potential,transition_matrices,gamma,all_one_state_rewards):
  col_number=len(transition_matrices)
  row_number=np.shape(all_one_state_rewards[0])[0]
  all_potentials=np.zeros((row_number,col_number))
  for i in range(col_number):
    reward=all_one_state_rewards[i]
    Vt = (reward+gamma*(np.matmul(transition_matrices[i],potential))).reshape(row_number,)
    #print(np.shape(Vt))
    #print(np.shape(all_potentials))
    all_potentials[:,i]=Vt
  policy = (np.argmax(all_potentials,axis=1)).tolist()
  return policy
from numpy.matrixlib.defmatrix import matrix
def matrix_policy_evaluation(policy,txn_matrices,single_state_rewards,gamma): # policy is a list
  number_states=np.shape(txn_matrices[0])[0]
  txn_matrix_policy=np.zeros((number_states,number_states))
  reward_matrix_policy=np.zeros((number_states,1))
  identity=np.identity(number_states)
  for i in range(len(policy)):
    action=policy[i]
    txn_matrix_policy[i,:]=txn_matrices[action][i]
    reward_matrix_policy[i,0]=single_state_rewards[action][i]
  #print("txn matrix")
  #print(txn_matrix_policy)
  #print("reward matrix policy")
  #print(reward_matrix_policy)
  potential=np.matmul(np.linalg.inv(identity-gamma*txn_matrix_policy),reward_matrix_policy)
  return potential


def matrix_policy_iteration(intial_policy, txn_matrices, single_state_rewards, gamma):
    diff_exsists = True
    iter = 0
    while (diff_exsists):
        iter += 1
        if (iter > 1000):
            break
        final_potential = matrix_policy_evaluation(intial_policy, txn_matrices, single_state_rewards, gamma)
        new_policy = matrix_policy_improv(final_potential, txn_matrices, gamma, single_state_rewards)
        diff_exsists = not (new_policy == intial_policy)
        intial_policy = new_policy
    return intial_policy, final_potential, iter

def check_conv(potential1,potential2,threshold):
  rows=np.shape(potential1)[0]
  maxlist=[]
  assert(rows==np.shape(potential2)[0])
  #print(np.shape(potential2))
  #print(np.shape(potential1))
  for i in range(rows):
    maxlist.append(np.abs(potential1[i,0]-potential2[i,0]))
  if(max(maxlist)<threshold):
    return True
  return False
def matrix_value_iteration(threshold,gamma,all_one_state_rewards,transition_matrices,intial_potential):
  iter1=0
  col_number=len(transition_matrices)
  row_number=np.shape(all_one_state_rewards[0])[0]
  all_potentials=np.zeros((row_number,col_number))
  conv=False
  while(conv==False):
    iter1+=1
    while(iter1>1000):
      break
    for i in range(col_number):
      reward=all_one_state_rewards[i]
      Vt = (reward+gamma*(np.matmul(transition_matrices[i],intial_potential))).reshape(row_number,)
      all_potentials[:,i]=Vt
    final_potential=np.amax(all_potentials,axis=1).reshape(row_number,1)
    #print("in method {}".format(final_potential))
    conv=check_conv(final_potential,intial_potential,threshold)
    intial_potential=final_potential
  return final_potential,iter1
def check_amax_fxn():
  test_arr=np.array([[2.27,0.6146],[2.81,3.04]])
  arr=np.amax(test_arr,axis=1).reshape(2,1)
  print(arr)
check_amax_fxn()
def evaluate_performance(policy,intial_state_index,transition_matrices,states):  # policy has to be a list or array - say list
  state_index=intial_state_index
  action_to_do=policy[state_index]
  transition_matrix=transition_matrices[action_to_do]
  avg=0
  for i in range(100):
    episode_total=0
    for j in range(200):
      #state_index=np.argmax(transition_matrix[state_index],axis=1)
      state_index=np.random.choice(a=16,p=transition_matrix[state_index])
      episode_total+=computeL1Norm(states[state_index])
    avg+=episode_total/200
  avg=avg/100
  return avg

def run_mvi_case1():
  states=create_states()
  actions=define_action_space(0)
  connectivity_matrix = np.array([[0,0,-1,0],[1,0,-1,-1],[0,1,0,0],[-1,1,1,0]])
  txn_matrices=calc_transition_matrices(0.05,connectivity_matrix,states,actions)
  print(np.shape(txn_matrices))
  print("printing txn matrix of action 2-action3")
  print(np.linalg.det(txn_matrices[2]-txn_matrices[1]))
  two_state_rewards=create_all_two_state_rewards(states,actions)
  single_state_reward = create_all_single_state_rewards(two_state_rewards,txn_matrices)
  init_potential=np.zeros((16,1))
  final_potential,iter_vi_1=matrix_value_iteration(0.01,0.95,single_state_reward,txn_matrices,init_potential)
  print(final_potential)
  final_policy=matrix_policy_improv(final_potential,txn_matrices,0.95,single_state_reward)
  print(final_policy)
  for i in final_policy:
    print(actions[i])
  #choose random start state
  random_start_state=random.randrange(16)
  print("Number of iteration needed = {}".format(iter_vi_1))
  print("Starting with random state: {}".format(states[random_start_state]))
  print("Average activation obtained = {}".format(evaluate_performance(final_policy,random_start_state,txn_matrices,states)))
run_mvi_case1()

def run_mpi_case1():
  states=create_states()
  actions=define_action_space(1)
  connectivity_matrix = np.array([[0,0,-1,0],[1,0,-1,-1],[0,1,0,0],[-1,1,1,0]])
  txn_matrices=calc_transition_matrices(0.05,connectivity_matrix,states,actions)
  print(np.shape(txn_matrices))
  #print(txn_matrices[0])
  two_state_rewards=create_all_two_state_rewards(states,actions)
  single_state_reward = create_all_single_state_rewards(two_state_rewards,txn_matrices)
  init_potential=np.zeros((16,1))
  initial_policy=[0]*16
  final_policy,final_potential,iter=matrix_policy_iteration(initial_policy,txn_matrices,single_state_reward,0.95)
  print("final potential")
  print("value=",final_potential.T)
  print("policy=",final_policy)
  for i in final_policy:
    print(actions[i])
  #choose random start state
  random_start_state=random.randrange(16)
  print("Number of iteration needed = {}".format(iter))
  print("Starting with random state: {}".format(states[random_start_state]))
  print("Average activation obtained = {}".format(evaluate_performance(final_policy,random_start_state,txn_matrices,states)))
run_mpi_case1()

def run_base_case():
  states=create_states()
  actions=define_action_space(0)
  connectivity_matrix = np.array([[0,0,-1,0],[1,0,-1,-1],[0,1,0,0],[-1,1,1,0]])
  txn_matrices=calc_transition_matrices(0.05,connectivity_matrix,states,actions)
  print(np.shape(txn_matrices))
  #print(txn_matrices[0])
  two_state_rewards=create_all_two_state_rewards(states,actions)
  single_state_reward = create_all_single_state_rewards(two_state_rewards,txn_matrices)
  init_potential=np.zeros((16,1))
  #final_potential,iter_vi_1=matrix_value_iteration(0.01,0.95,single_state_reward,txn_matrices,init_potential)
  #print(final_potential)
  #final_policy=matrix_policy_improv(final_potential,txn_matrices,0.95,single_state_reward)
  final_policy=[0]*16
  print("final policy: {}".format(final_policy))
  for i in final_policy:
    print("action = {}".format(actions[int(i)]))
  #choose random start state
  random_start_state=random.randrange(16)
  print("Starting with random state: {}".format(states[random_start_state]))
  print("Average activation obtained = {}".format(evaluate_performance(final_policy,random_start_state,txn_matrices,states)))
run_base_case()

def run_mvi_case2():
  states=create_states()
  actions=define_action_space(1)
  connectivity_matrix = np.array([[0,0,-1,0],[1,0,-1,-1],[0,1,0,0],[-1,1,1,0]])
  txn_matrices=calc_transition_matrices(0.2,connectivity_matrix,states,actions)
  print(np.shape(txn_matrices))
  #print(txn_matrices[0])
  two_state_rewards=create_all_two_state_rewards(states,actions)
  single_state_reward = create_all_single_state_rewards(two_state_rewards,txn_matrices)
  init_potential=np.zeros((16,1))
  final_potential,iter_vi_1=matrix_value_iteration(0.01,0.95,single_state_reward,txn_matrices,init_potential)
  print("values=",final_potential.T)
  final_policy=matrix_policy_improv(final_potential,txn_matrices,0.95,single_state_reward)
  print("policy=",final_policy)
  for i in final_policy:
    print(actions[i])
  #choose random start state
  random_start_state=random.randrange(16)
  print("Number of iteration needed = {}".format(iter_vi_1))
  print("Starting with random state: {}".format(states[random_start_state]))
  print("Average activation obtained = {}".format(evaluate_performance(final_policy,random_start_state,txn_matrices,states)))
run_mvi_case2()

def run_mvi_case3():
  states=create_states()
  actions=define_action_space(1)
  connectivity_matrix = np.array([[0,0,-1,0],[1,0,-1,-1],[0,1,0,0],[-1,1,1,0]])
  txn_matrices=calc_transition_matrices(0.45,connectivity_matrix,states,actions)
  print(np.shape(txn_matrices))
  #print(txn_matrices[0])
  two_state_rewards=create_all_two_state_rewards(states,actions)
  single_state_reward = create_all_single_state_rewards(two_state_rewards,txn_matrices)
  init_potential=np.zeros((16,1))
  final_potential,iter_vi_1=matrix_value_iteration(0.01,0.95,single_state_reward,txn_matrices,init_potential)
  print("values=",final_potential.T)
  final_policy=matrix_policy_improv(final_potential,txn_matrices,0.95,single_state_reward)
  print(final_policy)
  for i in final_policy:
    print("policy=",actions[i])
  #choose random start state
  random_start_state=random.randrange(16)
  print("Number of iteration needed = {}".format(iter_vi_1))
  print("Starting with random state: {}".format(states[random_start_state]))
  print("Average activation obtained = {}".format(evaluate_performance(final_policy,random_start_state,txn_matrices,states)))
run_mvi_case3()

def run_mvi_case4():
  states=create_states()
  actions=define_action_space(1)
  connectivity_matrix = np.array([[0,0,-1,0],[1,0,-1,-1],[0,1,0,0],[-1,1,1,0]])
  txn_matrices=calc_transition_matrices(0.05,connectivity_matrix,states,actions)
  print(np.shape(txn_matrices))
  #print(txn_matrices[0])
  two_state_rewards=create_all_two_state_rewards(states,actions)
  single_state_reward = create_all_single_state_rewards(two_state_rewards,txn_matrices)
  init_potential=np.zeros((16,1))
  final_potential,iter_vi_1=matrix_value_iteration(0.01,0.95,single_state_reward,txn_matrices,init_potential)
  print("values=",final_potential.T)
  final_policy=matrix_policy_improv(final_potential,txn_matrices,0.95,single_state_reward)
  print("policy=",final_policy)
  for i in final_policy:
    print(actions[i])
  #choose random start state
  random_start_state=random.randrange(16)
  print("Number of iteration needed = {}".format(iter_vi_1))
  print("Starting with random state: {}".format(states[random_start_state]))
  print("Average activation obtained = {}".format(evaluate_performance(final_policy,random_start_state,txn_matrices,states)))
run_mvi_case4()

def run_base_case2():
  states=create_states()
  actions=define_action_space(0)
  connectivity_matrix = np.array([[0,0,-1,0],[1,0,-1,-1],[0,1,0,0],[-1,1,1,0]])
  txn_matrices=calc_transition_matrices(0.2,connectivity_matrix,states,actions)
  print(np.shape(txn_matrices))
  #print(txn_matrices[0])
  two_state_rewards=create_all_two_state_rewards(states,actions)
  single_state_reward = create_all_single_state_rewards(two_state_rewards,txn_matrices)
  init_potential=np.zeros((16,1))
  #final_potential,iter_vi_1=matrix_value_iteration(0.01,0.95,single_state_reward,txn_matrices,init_potential)
  #print(final_potential)
  #final_policy=matrix_policy_improv(final_potential,txn_matrices,0.95,single_state_reward)
  final_policy=[0]*16
  print("final policy: {}".format(final_policy))
  for i in final_policy:
    print("action = {}".format(actions[int(i)]))
  #choose random start state
  random_start_state=random.randrange(16)
  print("Starting with random state: {}".format(states[random_start_state]))
  print("Average activation obtained = {}".format(evaluate_performance(final_policy,random_start_state,txn_matrices,states)))
run_base_case2()

def run_base_case3():
  states=create_states()
  actions=define_action_space(1)
  connectivity_matrix = np.array([[0,0,-1,0],[1,0,-1,-1],[0,1,0,0],[-1,1,1,0]])
  txn_matrices=calc_transition_matrices(0.45,connectivity_matrix,states,actions)
  print(np.shape(txn_matrices))
  #print(txn_matrices[0])
  two_state_rewards=create_all_two_state_rewards(states,actions)
  single_state_reward = create_all_single_state_rewards(two_state_rewards,txn_matrices)
  init_potential=np.zeros((16,1))
  #final_potential,iter_vi_1=matrix_value_iteration(0.01,0.95,single_state_reward,txn_matrices,init_potential)
  #print(final_potential)
  #final_policy=matrix_policy_improv(final_potential,txn_matrices,0.95,single_state_reward)
  final_policy=[0]*16
  print("final policy: {}".format(final_policy))
  for i in final_policy:
    print("action = {}".format(actions[int(i)]))
  #choose random start state
  random_start_state=random.randrange(16)
  print("Starting with random state: {}".format(states[random_start_state]))
  print("Average activation obtained = {}".format(evaluate_performance(final_policy,random_start_state,txn_matrices,states)))
run_base_case3()

